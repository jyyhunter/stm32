#include "stm32f10x.h"
#include "OLED_Font.h"
#include "Delay.h"

/* ============================================================
 *  0.96 �� OLED 128x64 SSD1306 ���� I2C ����
 *    SCL : PB8   SDA : PB9
 *
 *  ������Խ��ƴ����̵ĸĶ�����߽��߼����ԣ���
 *    1) SCL/SDA ���������������Ӧ��ʱ SDA ���������룬
 *       ��ʹ OLED ģ��û�а�����������Ҳ��ͨ�ţ�
 *    2) I2C ʱ����� 2us ��ʱ��Լ 200kHz�������ݽ�����ģ�飻
 *    3) OLED_Init �Զ��� 0x78 / 0x7A ������ַ��̽�⣬
 *       ������� OLED_IsReady() / OLED_GetAddr() ��ȡ��
 * ============================================================ */

#define OLED_SCL_PORT  GPIOB
#define OLED_SCL_PIN   GPIO_Pin_8
#define OLED_SDA_PORT  GPIOB
#define OLED_SDA_PIN   GPIO_Pin_9

static uint8_t OLED_Addr = 0x78;   /* 8λд��ַ��0x78(0x3C) �� 0x7A(0x3D) */
static uint8_t OLED_Ready = 0;     /* 1=��⵽ OLED */

static void OLED_SCL_Write(uint8_t v) { if (v) GPIO_SetBits(OLED_SCL_PORT, OLED_SCL_PIN); else GPIO_ResetBits(OLED_SCL_PORT, OLED_SCL_PIN); }
static void OLED_SDA_Write(uint8_t v) { if (v) GPIO_SetBits(OLED_SDA_PORT, OLED_SDA_PIN); else GPIO_ResetBits(OLED_SDA_PORT, OLED_SDA_PIN); }
static uint8_t OLED_SDA_Read(void)    { return GPIO_ReadInputDataBit(OLED_SDA_PORT, OLED_SDA_PIN); }

/* SDA �����������������/��� */
static void OLED_SDA_SetOutput(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = OLED_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(OLED_SDA_PORT, &GPIO_InitStructure);
}

/* SDA �������루�ͷ����ߣ���ȡ�ӻ�Ӧ�� */
static void OLED_SDA_SetInput(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = OLED_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(OLED_SDA_PORT, &GPIO_InitStructure);
}

static void OLED_I2C_Delay(void) { Delay_us(2); }

void OLED_I2C_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	/* SCL ������� */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = OLED_SCL_PIN;
	GPIO_Init(OLED_SCL_PORT, &GPIO_InitStructure);

	/* SDA ������� */
	OLED_SDA_SetOutput();

	OLED_SCL_Write(1);
	OLED_SDA_Write(1);
}

void OLED_I2C_Start(void)
{
	OLED_SDA_SetOutput();
	OLED_SDA_Write(1);
	OLED_SCL_Write(1);
	OLED_I2C_Delay();
	OLED_SDA_Write(0);
	OLED_I2C_Delay();
	OLED_SCL_Write(0);
	OLED_I2C_Delay();
}

void OLED_I2C_Stop(void)
{
	OLED_SDA_SetOutput();
	OLED_SDA_Write(0);
	OLED_I2C_Delay();
	OLED_SCL_Write(1);
	OLED_I2C_Delay();
	OLED_SDA_Write(1);
	OLED_I2C_Delay();
}

/* ����һ���ֽڣ����� 0=�յ�ACK��1=��Ӧ�� */
static uint8_t OLED_I2C_SendByte(uint8_t Byte)
{
	uint8_t i, ack;
	OLED_SDA_SetOutput();
	for (i = 0; i < 8; i++)
	{
		OLED_SCL_Write(0);
		OLED_SDA_Write(!!(Byte & (0x80 >> i)));
		OLED_I2C_Delay();
		OLED_SCL_Write(1);
		OLED_I2C_Delay();
	}
	OLED_SCL_Write(0);
	OLED_SDA_SetInput();          /* �ͷ� SDA����Ӧ�� */
	OLED_I2C_Delay();
	OLED_SCL_Write(1);
	OLED_I2C_Delay();
	ack = OLED_SDA_Read();       /* 0=ACK */
	OLED_SCL_Write(0);
	OLED_SDA_SetOutput();
	OLED_SDA_Write(1);
	return ack;
}

/* ̽��ĳ 8 λд��ַ�Ƿ���Ӧ�𣬷��� 0=��Ӧ�� */
static uint8_t OLED_ProbeAddr(uint8_t addr)
{
	uint8_t ack;
	OLED_I2C_Start();
	ack = OLED_I2C_SendByte(addr);
	OLED_I2C_Stop();
	return ack;
}

/* �� PB8/PB9 ��ɨ�� OLED������ 0x78 / 0x7A / 0(δ�ҵ�) */
uint8_t OLED_ScanAddr(void)
{
	OLED_I2C_Init();
	Delay_ms(20);
	if (OLED_ProbeAddr(0x78) == 0)
	{
		return 0x78;
	}
	if (OLED_ProbeAddr(0x7A) == 0)
	{
		return 0x7A;
	}
	return 0;
}

void OLED_WriteCommand(uint8_t Command)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(OLED_Addr);
	OLED_I2C_SendByte(0x00);
	OLED_I2C_SendByte(Command);
	OLED_I2C_Stop();
}

void OLED_WriteData(uint8_t Data)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(OLED_Addr);
	OLED_I2C_SendByte(0x40);
	OLED_I2C_SendByte(Data);
	OLED_I2C_Stop();
}

void OLED_SetCursor(uint8_t Y, uint8_t X)
{
	OLED_WriteCommand(0xB0 | Y);
	OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));
	OLED_WriteCommand(0x00 | (X & 0x0F));
}

void OLED_Clear(void)
{
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		OLED_SetCursor(j, 0);
		for(i = 0; i < 128; i++)
		{
			OLED_WriteData(0x00);
		}
	}
}

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{
	uint8_t i;
	OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i]);
	}
	OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i + 8]);
	}
}

void OLED_ShowString(uint8_t Line, uint8_t Column, char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar(Line, Column + i, String[i]);
	}
}

uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)
	{
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i, SingleNumber;
	for (i = 0; i < Length; i++)
	{
		SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
		if (SingleNumber < 10)
		{
			OLED_ShowChar(Line, Column + i, SingleNumber + '0');
		}
		else
		{
			OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A');
		}
	}
}

void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
	}
}

void OLED_Init(void)
{
	OLED_Addr = OLED_ScanAddr();   /* �ϵ��ȶ� + �Զ�̽���ַ */
	if (OLED_Addr != 0)
	{
		OLED_Ready = 1;
	}
	else
	{
		OLED_Addr = 0x78;          /* δ̽�⵽Ҳ�� 0x78 ���������ں������� */
		OLED_Ready = 0;
	}

	OLED_WriteCommand(0xAE);
	OLED_WriteCommand(0xD5);
	OLED_WriteCommand(0x80);
	OLED_WriteCommand(0xA8);
	OLED_WriteCommand(0x3F);
	OLED_WriteCommand(0xD3);
	OLED_WriteCommand(0x00);
	OLED_WriteCommand(0x40);
	OLED_WriteCommand(0xA1);
	OLED_WriteCommand(0xC8);
	OLED_WriteCommand(0xDA);
	OLED_WriteCommand(0x12);
	OLED_WriteCommand(0x81);
	OLED_WriteCommand(0xCF);
	OLED_WriteCommand(0xD9);
	OLED_WriteCommand(0xF1);
	OLED_WriteCommand(0xDB);
	OLED_WriteCommand(0x30);
	OLED_WriteCommand(0xA4);
	OLED_WriteCommand(0xA6);
	OLED_WriteCommand(0x8D);
	OLED_WriteCommand(0x14);
	OLED_WriteCommand(0xAF);

	OLED_Clear();
}

uint8_t OLED_IsReady(void) { return OLED_Ready; }
uint8_t OLED_GetAddr(void) { return OLED_Addr; }
